const express = require('express');
const router = express.Router();

const saucesCtrl = require('../controllers/sauces');
const auth = require('../middleware/auth');
const multer = require('../middleware/multer-config');

router.get('/', auth, saucesCtrl.getAllThings);
router.post('/', auth, multer, saucesCtrl.createThing);
router.get('/:_id', auth, saucesCtrl.getOneThing);
router.put('/:_id', auth, multer, saucesCtrl.modifyThing);
router.delete('/:_id', auth, saucesCtrl.deleteThing);
router.post('/:_id', auth, saucesCtrl.likes);
router.post('/:_id', auth, saucesCtrl.dislikes);


module.exports = router;